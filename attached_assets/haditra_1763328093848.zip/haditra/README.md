
  # AI Call Analytics SaaS Landing Page

  This is a code bundle for AI Call Analytics SaaS Landing Page. The original project is available at https://www.figma.com/design/S9oedCA1IRTCa2e8PH5406/AI-Call-Analytics-SaaS-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  