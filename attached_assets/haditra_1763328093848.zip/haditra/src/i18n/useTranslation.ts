import { useI18n, Language } from './index';
import en from './locales/en';
import es from './locales/es';
import fr from './locales/fr';
import de from './locales/de';
import zh from './locales/zh';
import ja from './locales/ja';
import ko from './locales/ko';
import ar from './locales/ar';
import pt from './locales/pt';
import ru from './locales/ru';
import tr from './locales/tr';
import it from './locales/it';
import nl from './locales/nl';
import hi from './locales/hi';

const translations: Record<Language, typeof en> = {
  en,
  es,
  fr,
  de,
  zh,
  ja,
  ko,
  ar,
  pt,
  ru,
  tr,
  it,
  nl,
  hi,
};

export function useTranslation() {
  const { language } = useI18n();
  
  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[language];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return key;
      }
    }
    
    return typeof value === 'string' ? value : key;
  };

  return { t, language };
}