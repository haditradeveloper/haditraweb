export default {
  nav: {
    home: "Inicio",
    about: "Sobre Nosotros",
    software: "Soluciones de Software",
    ai: "IA y Tecnologías",
    creative: "Estudio Creativo",
    portfolio: "Portafolio",
    contact: "Contacto"
  },
  hero: {
    subtitle: "Tecnología Premium y Soluciones Creativas",
    title: "Transforme Su Visión en Excelencia Digital",
    description: "Haditra Technologies & Creative Solutions L.L.C. ofrece sistemas de software empresarial, soluciones de IA de alto rendimiento y servicios profesionales de producción visual. Combinamos ingeniería avanzada con excelencia creativa.",
    cta1: "Comenzar",
    cta2: "Ver Portafolio"
  },
  stats: {
    projects: "Proyectos Entregados",
    clients: "Clientes Satisfechos",
    experience: "Años de Experiencia",
    team: "Miembros del Equipo"
  },
  services: {
    subtitle: "Nuestros Servicios",
    title: "Soluciones Tecnológicas y Creativas Integrales",
    description: "Desde software empresarial hasta sistemas impulsados por IA y producción creativa profesional, ofrecemos excelencia en todos los ámbitos.",
    software: {
      title: "Ingeniería de Software",
      description: "Soluciones de software personalizadas de nivel empresarial que incluyen sistemas de pago, billeteras digitales, ERP, sistemas de RRHH y plataformas de automatización.",
      feat1: "Sistemas de Pago",
      feat2: "Soluciones de Billetera Digital",
      feat3: "Sistemas ERP y RRHH"
    },
    ai: {
      title: "IA y Tecnologías Avanzadas",
      description: "Soluciones de inteligencia artificial de vanguardia, aprendizaje automático, sistemas IoT, reconocimiento facial y análisis predictivo.",
      feat1: "Aprendizaje Automático",
      feat2: "Reconocimiento Facial",
      feat3: "Integración IoT"
    },
    creative: {
      title: "Estudio Creativo",
      description: "Fotografía profesional, producción de video, grabación con drones, motion graphics, animación 2D/3D y creación de contenido AR/VR.",
      feat1: "Producción de Video",
      feat2: "Animación 3D",
      feat3: "Desarrollo AR/VR"
    }
  },
  values: {
    subtitle: "Por Qué Elegir Haditra",
    title: "Basado en Excelencia e Innovación",
    quality: {
      title: "Calidad Premium",
      description: "Soluciones de nivel empresarial con atención meticulosa al detalle"
    },
    results: {
      title: "Orientado a Resultados",
      description: "Enfocado en entregar resultados empresariales medibles"
    },
    innovation: {
      title: "Innovación Primero",
      description: "Aprovechando tecnologías de vanguardia y enfoques creativos"
    },
    scalable: {
      title: "Soluciones Escalables",
      description: "Construido para crecer con las necesidades de su negocio"
    }
  },
  testimonials: {
    subtitle: "Testimonios de Clientes",
    title: "Confiado por Organizaciones Líderes",
    test1: {
      name: "Ahmed Al-Maktoum",
      role: "CEO, Dubai Tech Ventures",
      content: "Haditra entregó un sistema ERP excepcional que transformó nuestras operaciones. Su experiencia técnica y enfoque profesional superaron nuestras expectativas."
    },
    test2: {
      name: "Sarah Johnson",
      role: "Directora, Global Finance Corp",
      content: "La plataforma de análisis impulsada por IA desarrollada por Haditra nos ha brindado información sin precedentes sobre nuestro negocio. Soluciones verdaderamente innovadoras."
    },
    test3: {
      name: "Mohammed Hassan",
      role: "Jefe de Marketing, Luxury Brands ME",
      content: "¡Trabajo creativo excepcional! Su producción de video y motion graphics elevaron la presentación de nuestra marca a un nivel de clase mundial."
    }
  },
  cta: {
    title: "¿Listo para Transformar su Negocio?",
    description: "Discutamos cómo nuestras soluciones tecnológicas y creativas pueden impulsar su éxito. Póngase en contacto con nuestro equipo de expertos hoy.",
    button1: "Iniciar su Proyecto",
    button2: "Saber Más"
  },
  footer: {
    tagline: "Empresa premium de tecnología y producción creativa que ofrece soluciones empresariales.",
    solutions: "Soluciones",
    company: "Empresa",
    contact: "Contacto",
    careers: "Carreras",
    privacy: "Política de Privacidad",
    location: "Dubái, Emiratos Árabes Unidos",
    rights: "Todos los derechos reservados."
  },
  common: {
    loading: "Cargando...",
    language: "Idioma"
  }
};
