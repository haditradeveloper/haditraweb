export default {
  nav: {
    home: "Accueil",
    about: "À Propos",
    software: "Solutions Logicielles",
    ai: "IA et Technologies",
    creative: "Studio Créatif",
    portfolio: "Portfolio",
    contact: "Contact"
  },
  hero: {
    subtitle: "Technologie Premium et Solutions Créatives",
    title: "Transformez Votre Vision en Excellence Numérique",
    description: "Haditra Technologies & Creative Solutions L.L.C. propose des systèmes logiciels d'entreprise, des solutions IA haute performance et des services de production visuelle professionnels. Nous combinons ingénierie avancée et excellence créative.",
    cta1: "Commencer",
    cta2: "Voir le Portfolio"
  },
  stats: {
    projects: "Projets Livrés",
    clients: "Clients Satisfaits",
    experience: "Années d'Expérience",
    team: "Membres de l'Équipe"
  },
  services: {
    subtitle: "Nos Services",
    title: "Solutions Technologiques et Créatives Complètes",
    description: "Des logiciels d'entreprise aux systèmes alimentés par l'IA et la production créative professionnelle, nous offrons l'excellence dans tous les domaines.",
    software: {
      title: "Ingénierie Logicielle",
      description: "Solutions logicielles personnalisées de niveau entreprise incluant systèmes de paiement, portefeuilles numériques, ERP, systèmes RH et plateformes d'automatisation.",
      feat1: "Systèmes de Paiement",
      feat2: "Solutions de Portefeuille Numérique",
      feat3: "Systèmes ERP et RH"
    },
    ai: {
      title: "IA et Technologies Avancées",
      description: "Solutions d'intelligence artificielle de pointe, apprentissage automatique, systèmes IoT, reconnaissance faciale et analyses prédictives.",
      feat1: "Apprentissage Automatique",
      feat2: "Reconnaissance Faciale",
      feat3: "Intégration IoT"
    },
    creative: {
      title: "Studio Créatif",
      description: "Photographie professionnelle, production vidéo, tournage par drone, motion graphics, animation 2D/3D et création de contenu AR/VR.",
      feat1: "Production Vidéo",
      feat2: "Animation 3D",
      feat3: "Développement AR/VR"
    }
  },
  values: {
    subtitle: "Pourquoi Choisir Haditra",
    title: "Fondé sur l'Excellence et l'Innovation",
    quality: {
      title: "Qualité Premium",
      description: "Solutions de niveau entreprise avec une attention méticuleuse aux détails"
    },
    results: {
      title: "Axé sur les Résultats",
      description: "Concentré sur la livraison de résultats commerciaux mesurables"
    },
    innovation: {
      title: "Innovation d'Abord",
      description: "Exploitation des technologies de pointe et des approches créatives"
    },
    scalable: {
      title: "Solutions Évolutives",
      description: "Conçu pour évoluer avec les besoins de votre entreprise"
    }
  },
  testimonials: {
    subtitle: "Témoignages Clients",
    title: "Approuvé par les Organisations Leaders",
    test1: {
      name: "Ahmed Al-Maktoum",
      role: "PDG, Dubai Tech Ventures",
      content: "Haditra a livré un système ERP exceptionnel qui a transformé nos opérations. Leur expertise technique et approche professionnelle ont dépassé nos attentes."
    },
    test2: {
      name: "Sarah Johnson",
      role: "Directrice, Global Finance Corp",
      content: "La plateforme d'analyse alimentée par l'IA développée par Haditra nous a donné des informations sans précédent sur notre entreprise. Des solutions vraiment innovantes."
    },
    test3: {
      name: "Mohammed Hassan",
      role: "Responsable Marketing, Luxury Brands ME",
      content: "Travail créatif exceptionnel! Leur production vidéo et motion graphics ont élevé la présentation de notre marque à un niveau mondial."
    }
  },
  cta: {
    title: "Prêt à Transformer Votre Entreprise?",
    description: "Discutons de la manière dont nos solutions technologiques et créatives peuvent favoriser votre succès. Contactez notre équipe d'experts dès aujourd'hui.",
    button1: "Démarrer Votre Projet",
    button2: "En Savoir Plus"
  },
  footer: {
    tagline: "Entreprise premium de technologie et de production créative offrant des solutions d'entreprise.",
    solutions: "Solutions",
    company: "Entreprise",
    contact: "Contact",
    careers: "Carrières",
    privacy: "Politique de Confidentialité",
    location: "Dubaï, Émirats Arabes Unis",
    rights: "Tous droits réservés."
  },
  common: {
    loading: "Chargement...",
    language: "Langue"
  }
};
