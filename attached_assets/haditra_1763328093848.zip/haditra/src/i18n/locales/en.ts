export default {
  nav: {
    home: "Home",
    about: "About Us",
    software: "Software Solutions",
    ai: "AI & Technologies",
    creative: "Creative Studio",
    portfolio: "Portfolio",
    contact: "Contact"
  },
  hero: {
    subtitle: "Premium Technology & Creative Solutions",
    title: "Transform Your Vision Into Digital Excellence",
    description: "Haditra Technologies & Creative Solutions L.L.C. delivers enterprise software systems, high-performance AI solutions, and professional visual production services. We combine advanced engineering with creative excellence.",
    cta1: "Get Started",
    cta2: "View Portfolio"
  },
  stats: {
    projects: "Projects Delivered",
    clients: "Happy Clients",
    experience: "Years Experience",
    team: "Team Members"
  },
  services: {
    subtitle: "Our Services",
    title: "Comprehensive Technology & Creative Solutions",
    description: "From enterprise software to AI-powered systems and professional creative production, we deliver excellence across all domains.",
    software: {
      title: "Software Engineering",
      description: "Enterprise-grade custom software solutions including payment systems, digital wallets, ERP, HR systems, and automation platforms.",
      feat1: "Payment Systems",
      feat2: "Digital Wallet Solutions",
      feat3: "ERP & HR Systems"
    },
    ai: {
      title: "AI & Advanced Technologies",
      description: "Cutting-edge artificial intelligence, machine learning, IoT systems, face recognition, and predictive analytics solutions.",
      feat1: "Machine Learning",
      feat2: "Face Recognition",
      feat3: "IoT Integration"
    },
    creative: {
      title: "Creative Studio",
      description: "Professional photography, video production, drone shooting, motion graphics, 2D/3D animation, and AR/VR content creation.",
      feat1: "Video Production",
      feat2: "3D Animation",
      feat3: "AR/VR Development"
    }
  },
  values: {
    subtitle: "Why Choose Haditra",
    title: "Built on Excellence & Innovation",
    quality: {
      title: "Premium Quality",
      description: "Enterprise-grade solutions with meticulous attention to detail"
    },
    results: {
      title: "Result-Driven",
      description: "Focused on delivering measurable business outcomes"
    },
    innovation: {
      title: "Innovation First",
      description: "Leveraging cutting-edge technologies and creative approaches"
    },
    scalable: {
      title: "Scalable Solutions",
      description: "Built to grow with your business needs"
    }
  },
  testimonials: {
    subtitle: "Client Testimonials",
    title: "Trusted by Leading Organizations",
    test1: {
      name: "Ahmed Al-Maktoum",
      role: "CEO, Dubai Tech Ventures",
      content: "Haditra delivered an exceptional ERP system that transformed our operations. Their technical expertise and professional approach exceeded our expectations."
    },
    test2: {
      name: "Sarah Johnson",
      role: "Director, Global Finance Corp",
      content: "The AI-powered analytics platform developed by Haditra has given us unprecedented insights into our business. Truly innovative solutions."
    },
    test3: {
      name: "Mohammed Hassan",
      role: "Marketing Head, Luxury Brands ME",
      content: "Outstanding creative work! Their video production and motion graphics elevated our brand presentation to a world-class level."
    }
  },
  cta: {
    title: "Ready to Transform Your Business?",
    description: "Let's discuss how our technology and creative solutions can drive your success. Get in touch with our expert team today.",
    button1: "Start Your Project",
    button2: "Learn More"
  },
  footer: {
    tagline: "Premium technology and creative production company delivering enterprise solutions.",
    solutions: "Solutions",
    company: "Company",
    contact: "Contact",
    careers: "Careers",
    privacy: "Privacy Policy",
    location: "Dubai, United Arab Emirates",
    rights: "All rights reserved."
  },
  common: {
    loading: "Loading...",
    language: "Language"
  }
};
