export default {
  nav: {home: "首页", about: "关于我们", software: "软件解决方案", ai: "人工智能与技术", creative: "创意工作室", portfolio: "作品集", contact: "联系我们"},
  hero: {subtitle: "高端技术与创意解决方案", title: "将您的愿景转化为数字卓越", description: "Haditra Technologies & Creative Solutions L.L.C. 提供企业软件系统、高性能AI解决方案和专业视觉制作服务。我们将先进工程与创意卓越相结合。", cta1: "开始使用", cta2: "查看作品集"},
  stats: {projects: "已交付项目", clients: "满意客户", experience: "年经验", team: "团队成员"},
  services: {subtitle: "我们的服务", title: "全面的技术和创意解决方案", description: "从企业软件到AI驱动系统和专业创意制作，我们在所有领域提供卓越服务。", software: {title: "软件工程", description: "企业级定制软件解决方案，包括支付系统、数字钱包、ERP、人力资源系统和自动化平台。", feat1: "支付系统", feat2: "数字钱包解决方案", feat3: "ERP和HR系统"}, ai: {title: "AI与先进技术", description: "尖端人工智能、机器学习、物联网系统、人脸识别和预测分析解决方案。", feat1: "机器学习", feat2: "人脸识别", feat3: "物联网集成"}, creative: {title: "创意工作室", description: "专业摄影、视频制作、无人机拍摄、动态图形、2D/3D动画和AR/VR内容创作。", feat1: "视频制作", feat2: "3D动画", feat3: "AR/VR开发"}},
  values: {subtitle: "为什么选择Haditra", title: "建立在卓越与创新之上", quality: {title: "高端品质", description: "企业级解决方案，注重每个细节"}, results: {title: "结果导向", description: "专注于提供可衡量的业务成果"}, innovation: {title: "创新优先", description: "利用尖端技术和创意方法"}, scalable: {title: "可扩展解决方案", description: "随您的业务需求而增长"}},
  testimonials: {subtitle: "客户推荐", title: "受领先组织信赖", test1: {name: "艾哈迈德·马克图姆", role: "首席执行官，迪拜科技风投", content: "Haditra交付了一个出色的ERP系统，改变了我们的运营。他们的技术专长和专业方法超出了我们的期望。"}, test2: {name: "莎拉·约翰逊", role: "董事，全球金融集团", content: "Haditra开发的AI驱动分析平台为我们的业务提供了前所未有的洞察。真正的创新解决方案。"}, test3: {name: "穆罕默德·哈桑", role: "营销主管，中东奢侈品牌", content: "出色的创意工作！他们的视频制作和动态图形将我们的品牌展示提升到了世界级水平。"}},
  cta: {title: "准备好转型您的业务了吗？", description: "让我们讨论我们的技术和创意解决方案如何推动您的成功。立即联系我们的专家团队。", button1: "启动您的项目", button2: "了解更多"},
  footer: {tagline: "提供企业解决方案的高端技术和创意制作公司。", solutions: "解决方案", company: "公司", contact: "联系", careers: "职业", privacy: "隐私政策", location: "迪拜，阿拉伯联合酋长国", rights: "保留所有权利。"},
  common: {loading: "加载中...", language: "语言"}
};
