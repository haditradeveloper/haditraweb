import { motion } from 'motion/react';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  description?: string;
  centered?: boolean;
}

export function SectionHeader({ title, subtitle, description, centered = true }: SectionHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className={centered ? 'text-center max-w-3xl mx-auto' : ''}
    >
      {subtitle && (
        <div className="text-[#3B82F6] text-sm tracking-wide uppercase mb-3 font-semibold">
          {subtitle}
        </div>
      )}
      <h2 className="text-[#0F172A] text-3xl lg:text-4xl font-bold tracking-tight mb-4">
        {title}
      </h2>
      {description && (
        <p className="text-[#64748B] text-lg leading-relaxed">
          {description}
        </p>
      )}
    </motion.div>
  );
}
