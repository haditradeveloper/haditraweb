import { ReactNode } from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

interface ServiceCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  features?: string[];
  delay?: number;
}

export function ServiceCard({ icon, title, description, features, delay = 0 }: ServiceCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="bg-slate-50 rounded-2xl p-8 border-2 border-transparent hover:border-[#3B82F6] hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
    >
      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#0F172A] to-[#1E293B] flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform duration-300">
        {icon}
      </div>
      <h3 className="text-[#0F172A] text-xl font-semibold mb-3">
        {title}
      </h3>
      <p className="text-[#64748B] mb-6 leading-relaxed">
        {description}
      </p>
      {features && features.length > 0 && (
        <ul className="space-y-3 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start gap-2 text-sm text-[#64748B]">
              <ArrowRight size={16} className="text-[#3B82F6] mt-0.5 flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      )}
      <div className="flex items-center gap-2 text-[#3B82F6] font-medium text-sm group-hover:gap-3 transition-all">
        <span>Learn more</span>
        <ArrowRight size={16} />
      </div>
    </motion.div>
  );
}
