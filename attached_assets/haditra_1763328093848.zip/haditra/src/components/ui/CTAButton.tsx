import { Link } from 'react-router-dom';
import { ReactNode } from 'react';

interface CTAButtonProps {
  to: string;
  children: ReactNode;
  variant?: 'primary' | 'secondary';
  className?: string;
}

export function CTAButton({ to, children, variant = 'primary', className = '' }: CTAButtonProps) {
  const baseStyles = 'inline-flex items-center justify-center px-8 py-4 rounded-full font-semibold text-base lg:text-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4';
  
  const variantStyles = {
    primary: 'bg-white text-slate-900 hover:bg-slate-100 shadow-xl hover:shadow-2xl focus:ring-white/50',
    secondary: 'border-2 border-white text-white hover:bg-white hover:text-slate-900 backdrop-blur-sm focus:ring-white/50'
  };

  return (
    <Link
      to={to}
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
    >
      {children}
    </Link>
  );
}
