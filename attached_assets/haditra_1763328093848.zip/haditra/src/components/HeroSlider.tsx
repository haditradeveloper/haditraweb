import { useCallback, useEffect, useState } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import Autoplay from 'embla-carousel-autoplay';
import Fade from 'embla-carousel-fade';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, ArrowRight, Sparkles } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Container } from './ui/Container';

interface Slide {
  id: number;
  image: string;
  category: string;
  title: string;
  subtitle: string;
  description: string;
}

const slides: Slide[] = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=1920&q=90',
    category: 'SOFTWARE ENGINEERING EXCELLENCE',
    title: 'Transform Your Vision',
    subtitle: 'Into Digital Reality',
    description: 'Enterprise-grade software solutions including ERP, HRMS, Payment Systems & E-Commerce Platforms'
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1920&q=90',
    category: 'ARTIFICIAL INTELLIGENCE & ML',
    title: 'Powered By Intelligence',
    subtitle: 'Driven By Innovation',
    description: 'Advanced AI solutions with Machine Learning, Predictive Analytics & Smart Systems'
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=1920&q=90',
    category: 'CREATIVE STUDIO SERVICES',
    title: 'Where Technology',
    subtitle: 'Meets Creativity',
    description: 'Professional Photography, Video Production, 3D Animation & AR/VR Development'
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1920&q=90',
    category: 'ENTERPRISE AUTOMATION',
    title: 'Automation That',
    subtitle: 'Transforms Business',
    description: 'IoT Integration, Smart Systems & RPA Solutions for Operational Excellence'
  }
];

export function HeroSlider() {
  const [emblaRef, emblaApi] = useEmblaCarousel(
    { loop: true, duration: 50 },
    [Fade(), Autoplay({ delay: 6000, stopOnMouseEnter: true })]
  );
  
  const [selectedIndex, setSelectedIndex] = useState(0);

  const scrollTo = useCallback((index: number) => {
    if (emblaApi) emblaApi.scrollTo(index);
  }, [emblaApi]);

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext();
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    const onSelect = () => setSelectedIndex(emblaApi.selectedScrollSnap());
    emblaApi.on('select', onSelect);
    onSelect();
    return () => { emblaApi.off('select', onSelect); };
  }, [emblaApi]);

  const currentSlide = slides[selectedIndex];

  return (
    <section className="relative w-full h-screen min-h-screen overflow-hidden bg-slate-950">
      <div className="embla absolute inset-0" ref={emblaRef}>
        <div className="embla__container flex h-full">
          {slides.map((slide) => (
            <div key={slide.id} className="embla__slide relative flex-[0_0_100%] min-w-0 h-full">
              <div className="absolute inset-0 w-full h-full">
                <ImageWithFallback src={slide.image} alt={slide.title} className="w-full h-full object-cover" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-br from-slate-950/85 via-slate-900/75 to-slate-950/90" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-transparent to-slate-950/60" />
            </div>
          ))}
        </div>
      </div>

      <div className="absolute inset-0 flex items-center justify-center z-20">
        <Container className="px-6 lg:px-16">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1 }}
              className="text-center max-w-6xl mx-auto"
            >
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.8 }}
                className="mb-8"
              >
                <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-xl border border-blue-400/30">
                  <Sparkles className="w-4 h-4 text-blue-400" />
                  <span className="text-sm lg:text-base text-blue-100 tracking-[0.2em] uppercase font-bold">
                    {currentSlide.category}
                  </span>
                </div>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.8 }}
                className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-100 to-white mb-4 tracking-tight leading-[0.9]"
              >
                {currentSlide.title}
              </motion.h1>

              <motion.h2
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.8 }}
                className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-light text-slate-200 mb-8 tracking-tight"
              >
                {currentSlide.subtitle}
              </motion.h2>

              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8, duration: 0.8 }}
                className="text-lg md:text-xl lg:text-2xl text-slate-300 mb-12 max-w-4xl mx-auto"
              >
                {currentSlide.description}
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1, duration: 0.8 }}
                className="flex flex-col sm:flex-row gap-5 justify-center"
              >
                <a
                  href="/portfolio"
                  className="group inline-flex items-center justify-center gap-3 px-10 py-5 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-bold text-lg transition-all duration-500 hover:scale-105 hover:shadow-[0_0_50px_rgba(59,130,246,0.5)]"
                >
                  View Our Work
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </a>
                <a
                  href="/contact"
                  className="inline-flex items-center justify-center px-10 py-5 border-2 border-white text-white rounded-full font-bold text-lg backdrop-blur-xl bg-white/5 transition-all duration-500 hover:bg-white hover:text-slate-900"
                >
                  Start Your Project
                </a>
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </Container>
      </div>

      <button
        onClick={scrollPrev}
        className="absolute left-6 lg:left-12 top-1/2 -translate-y-1/2 z-30 w-16 h-16 lg:w-20 lg:h-20 rounded-full bg-white/10 backdrop-blur-2xl border-2 border-white/30 flex items-center justify-center text-white transition-all duration-500 hover:bg-white hover:text-slate-900 hover:scale-110"
      >
        <ChevronLeft className="w-8 h-8" />
      </button>

      <button
        onClick={scrollNext}
        className="absolute right-6 lg:right-12 top-1/2 -translate-y-1/2 z-30 w-16 h-16 lg:w-20 lg:h-20 rounded-full bg-white/10 backdrop-blur-2xl border-2 border-white/30 flex items-center justify-center text-white transition-all duration-500 hover:bg-white hover:text-slate-900 hover:scale-110"
      >
        <ChevronRight className="w-8 h-8" />
      </button>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-30 flex gap-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => scrollTo(index)}
            className={`transition-all duration-500 rounded-full ${
              index === selectedIndex
                ? 'w-16 h-3 bg-white shadow-lg'
                : 'w-3 h-3 bg-white/40 hover:bg-white/80'
            }`}
          />
        ))}
      </div>
    </section>
  );
}
