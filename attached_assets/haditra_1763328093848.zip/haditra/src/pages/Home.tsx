import { motion } from 'motion/react';
import { HeroSlider } from '../components/HeroSlider';
import { Container } from '../components/ui/Container';
import { SectionHeader } from '../components/ui/SectionHeader';
import { ServiceCard } from '../components/ui/ServiceCard';
import { CTAButton } from '../components/ui/CTAButton';
import { Code2, Brain, Camera } from 'lucide-react';

export function Home() {
  const services = [
    {
      icon: <Code2 size={32} />,
      title: 'Software Engineering',
      description: 'Enterprise-grade custom software solutions including payment systems, ERP, HR systems.',
      features: ['Payment Systems', 'ERP & HRMS', 'E-Commerce']
    },
    {
      icon: <Brain size={32} />,
      title: 'AI & Technologies',
      description: 'Cutting-edge AI, machine learning, IoT systems, and predictive analytics solutions.',
      features: ['Machine Learning', 'IoT Integration', 'Smart Systems']
    },
    {
      icon: <Camera size={32} />,
      title: 'Creative Studio',
      description: 'Professional photography, video production, 3D animation, and AR/VR content.',
      features: ['Video Production', '3D Animation', 'Photography']
    }
  ];

  const stats = [
    { value: '500+', label: 'Projects Delivered' },
    { value: '200+', label: 'Happy Clients' },
    { value: '50+', label: 'Team Members' },
    { value: '98%', label: 'Client Satisfaction' }
  ];

  return (
    <div className="min-h-screen">
      <HeroSlider />
      
      <section className="py-20 bg-white">
        <Container>
          <SectionHeader
            subtitle="Our Impact"
            title="Delivering Excellence Across Industries"
          />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-bold text-[#1D4E89] mb-2">
                  {stat.value}
                </div>
                <div className="text-[#64748B] text-sm md:text-base">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 bg-[#F4F7FB]">
        <Container>
          <SectionHeader
            subtitle="Our Services"
            title="Comprehensive Technology & Creative Solutions"
          />
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            {services.map((service, index) => (
              <ServiceCard
                key={index}
                icon={service.icon}
                title={service.title}
                description={service.description}
                features={service.features}
                delay={index * 0.1}
              />
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 bg-slate-50">
        <Container>
          <div className="bg-white rounded-3xl p-12 shadow-xl text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-[#1D4E89] mb-4">
                Ready to Capture Your Story?
              </h2>
              <p className="text-[#64748B] text-lg mb-8 max-w-2xl mx-auto">
                Let's create stunning visual memories together. Book a consultation to discuss your photography and videography needs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <CTAButton to="/contact">Book a Session</CTAButton>
                <CTAButton to="/portfolio" variant="secondary">Explore Portfolio</CTAButton>
              </div>
            </motion.div>
          </div>
        </Container>
      </section>
    </div>
  );
}
