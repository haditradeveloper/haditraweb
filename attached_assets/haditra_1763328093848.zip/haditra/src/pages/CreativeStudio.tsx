import { motion } from 'motion/react';
import { Container } from '../components/ui/Container';
import { SectionHeader } from '../components/ui/SectionHeader';
import { ServiceCard } from '../components/ui/ServiceCard';
import { CTAButton } from '../components/ui/CTAButton';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { 
  Camera, 
  Video, 
  Plane, 
  Package,
  Wand2,
  Film,
  Palette,
  Glasses,
  Play,
  Image as ImageIcon,
  Sparkles,
  Monitor
} from 'lucide-react';

export function CreativeStudio() {
  const services = [
    {
      icon: <Camera size={24} />,
      title: 'Professional Photography',
      description: 'Premium commercial photography services including corporate, product, architectural, and event photography with meticulous attention to lighting and composition.',
      features: ['Corporate portraits', 'Product photography', 'Event coverage', 'Architectural shots']
    },
    {
      icon: <Video size={24} />,
      title: 'Video Production',
      description: 'Full-service video production from concept to final delivery, including corporate videos, commercials, documentaries, and brand storytelling.',
      features: ['Corporate videos', 'Commercial ads', 'Documentary films', 'Brand content']
    },
    {
      icon: <Plane size={24} />,
      title: 'Drone & Aerial Shooting',
      description: 'Stunning aerial cinematography and photography using professional-grade drones for real estate, events, construction, and promotional content.',
      features: ['Aerial cinematography', 'Real estate tours', 'Construction monitoring', 'Event coverage']
    },
    {
      icon: <Package size={24} />,
      title: 'Studio Product Shooting',
      description: 'Professional studio environment with controlled lighting for high-quality product photography that showcases details and drives sales.',
      features: ['E-commerce products', '360° photography', 'Lifestyle shots', 'White background']
    },
    {
      icon: <Wand2 size={24} />,
      title: 'Motion Graphics',
      description: 'Dynamic motion graphics and animated content for explainer videos, social media, presentations, and digital advertising campaigns.',
      features: ['Explainer videos', 'Social media content', 'Logo animation', 'Infographics']
    },
    {
      icon: <Film size={24} />,
      title: '2D/3D Animation',
      description: 'Character animation, product visualization, and immersive 3D experiences that bring concepts to life with stunning visual quality.',
      features: ['Character animation', '3D product renders', 'Architectural viz', 'Visual effects']
    },
    {
      icon: <Palette size={24} />,
      title: 'Graphic Design',
      description: 'Comprehensive graphic design services including branding, marketing materials, packaging design, and digital assets.',
      features: ['Brand identity', 'Marketing collateral', 'Packaging design', 'Digital assets']
    },
    {
      icon: <Glasses size={24} />,
      title: 'AR/VR/Hologram Production',
      description: 'Cutting-edge immersive experiences using augmented reality, virtual reality, and holographic displays for events and exhibitions.',
      features: ['AR applications', 'VR experiences', 'Hologram content', 'Interactive displays']
    }
  ];

  const portfolio = [
    { category: 'Corporate Video', client: 'Global Finance Corp', description: 'Brand documentary series' },
    { category: 'Product Photography', client: 'Luxury Brands ME', description: 'Fashion collection catalog' },
    { category: '3D Animation', client: 'Real Estate Developer', description: 'Architectural visualization' },
    { category: 'Motion Graphics', client: 'Tech Startup', description: 'Explainer video series' }
  ];

  return (
    <div>
      <section className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] py-20 text-white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="mb-6">Creative Studio Services</h1>
            <p className="text-lg text-white/90">
              Professional photography, video production, animation, and immersive content creation that elevates brands and captivates audiences.
            </p>
          </motion.div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-[#0A84FF] text-sm tracking-wide uppercase mb-4">
                Visual Excellence
              </div>
              <h2 className="text-[#1D4E89] mb-6">
                Where Creativity Meets Technical Precision
              </h2>
              <p className="text-[#AAB6C9] mb-4">
                Our creative studio combines artistic vision with technical expertise to produce visual content that resonates with audiences and drives results. From concept development to final delivery, we handle every aspect of the creative process.
              </p>
              <p className="text-[#AAB6C9] mb-6">
                Whether you need stunning product photography, compelling video content, or immersive 3D experiences, our team of creative professionals delivers premium quality that exceeds expectations.
              </p>
              <CTAButton to="/portfolio">View Our Work</CTAButton>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="rounded-2xl overflow-hidden shadow-xl"
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1673767297196-ce9739933932?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWRlbyUyMHByb2R1Y3Rpb24lMjBzdHVkaW98ZW58MXx8fHwxNzYzMTE0NzA1fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Video production studio"
                className="w-full h-auto"
              />
            </motion.div>
          </div>
        </Container>
      </section>

      <section className="py-20 bg-[#F4F7FB]">
        <Container>
          <SectionHeader
            subtitle="Creative Services"
            title="Complete Visual Production Capabilities"
            description="From traditional photography to cutting-edge AR/VR experiences, we offer the full spectrum of creative services."
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16">
            {services.map((service, index) => (
              <ServiceCard
                key={index}
                icon={service.icon}
                title={service.title}
                description={service.description}
                features={service.features}
                delay={index * 0.05}
              />
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <SectionHeader
            subtitle="Our Process"
            title="From Concept to Delivery"
            description="A streamlined creative process that ensures your vision is realized with precision and artistry."
          />

          <div className="grid md:grid-cols-4 gap-8 mt-16">
            {[
              { icon: <Sparkles size={28} />, title: 'Concept Development', desc: 'Collaborative ideation and creative planning' },
              { icon: <Camera size={28} />, title: 'Production', desc: 'Professional shooting and content creation' },
              { icon: <Monitor size={28} />, title: 'Post-Production', desc: 'Editing, color grading, and enhancement' },
              { icon: <Play size={28} />, title: 'Delivery', desc: 'Final formats optimized for your needs' }
            ].map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#1D4E89] to-[#276FBF] flex items-center justify-center text-white">
                  {step.icon}
                </div>
                <h3 className="text-[#1D4E89] mb-2">{step.title}</h3>
                <p className="text-[#AAB6C9] text-sm">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 bg-[#F4F7FB]">
        <Container>
          <SectionHeader
            subtitle="Recent Work"
            title="Featured Projects"
          />

          <div className="grid md:grid-cols-2 gap-6 mt-16">
            {portfolio.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 hover:shadow-lg transition-shadow border border-[#E9EEF5]"
              >
                <div className="text-[#0A84FF] text-sm uppercase tracking-wide mb-2">
                  {project.category}
                </div>
                <h3 className="text-[#1D4E89] mb-2">{project.client}</h3>
                <p className="text-[#AAB6C9]">{project.description}</p>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <CTAButton to="/portfolio">View Full Portfolio</CTAButton>
          </div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <div className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] rounded-3xl p-12 text-center text-white">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="mb-4">Ready to Create Something Amazing?</h2>
              <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
                Let's discuss your creative vision and bring it to life with professional photography, video, and animation services.
              </p>
              <CTAButton to="/contact">Start Your Project</CTAButton>
            </motion.div>
          </div>
        </Container>
      </section>
    </div>
  );
}
