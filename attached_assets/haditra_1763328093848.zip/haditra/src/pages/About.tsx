import { motion } from 'motion/react';
import { Container } from '../components/ui/Container';
import { SectionHeader } from '../components/ui/SectionHeader';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { CTAButton } from '../components/ui/CTAButton';
import { Target, Eye, Award, Zap, Shield, Users, Globe, Lightbulb } from 'lucide-react';

export function About() {
  const values = [
    {
      icon: <Award size={28} />,
      title: 'Excellence',
      description: 'We maintain the highest standards in every project, ensuring premium quality and attention to detail.'
    },
    {
      icon: <Lightbulb size={28} />,
      title: 'Innovation',
      description: 'We embrace cutting-edge technologies and creative approaches to solve complex challenges.'
    },
    {
      icon: <Shield size={28} />,
      title: 'Integrity',
      description: 'We build trust through transparent communication, ethical practices, and reliable delivery.'
    },
    {
      icon: <Users size={28} />,
      title: 'Collaboration',
      description: 'We work closely with clients as partners, ensuring their vision is realized with precision.'
    },
    {
      icon: <Zap size={28} />,
      title: 'Agility',
      description: 'We adapt quickly to changing requirements and deliver solutions with speed and efficiency.'
    },
    {
      icon: <Globe size={28} />,
      title: 'Global Perspective',
      description: 'We combine local expertise with international standards to deliver world-class solutions.'
    }
  ];

  const expertise = [
    'Enterprise Software Architecture',
    'Artificial Intelligence & Machine Learning',
    'Internet of Things (IoT)',
    'Cloud Computing & DevOps',
    'Payment Systems Integration',
    'Blockchain Technology',
    'Video Production & Post-Production',
    '3D Animation & Motion Graphics',
    'AR/VR Development',
    'Mobile App Development',
    'UI/UX Design',
    'Digital Marketing Solutions'
  ];

  return (
    <div>
      <section className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] py-20 text-white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="mb-6">About Haditra Technologies</h1>
            <p className="text-lg text-white/90">
              A premium technology and creative production company delivering enterprise-grade solutions that combine advanced engineering with creative excellence.
            </p>
          </motion.div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-[#0A84FF] text-sm tracking-wide uppercase mb-4">
                Our Story
              </div>
              <h2 className="text-[#1D4E89] mb-6">
                Pioneering Digital Transformation Since 2009
              </h2>
              <p className="text-[#AAB6C9] mb-4">
                Haditra Technologies & Creative Solutions L.L.C. was founded with a vision to bridge the gap between advanced technology and creative excellence. Based in Dubai, we have grown into a leading provider of enterprise software systems, AI-powered solutions, and professional creative production services.
              </p>
              <p className="text-[#AAB6C9] mb-6">
                Our multidisciplinary approach allows us to deliver comprehensive solutions that address both technical requirements and creative aspirations. From complex ERP systems to stunning visual content, we bring together the best of both worlds.
              </p>
              <CTAButton to="/portfolio">View Our Work</CTAButton>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1709715357520-5e1047a2b691?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHRlYW0lMjBtZWV0aW5nfGVufDF8fHx8MTc2MzExNzg4NHww&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Haditra team collaboration"
                  className="w-full h-auto"
                />
              </div>
            </motion.div>
          </div>
        </Container>
      </section>

      <section className="py-20 bg-[#F4F7FB]">
        <Container>
          <div className="grid md:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-white rounded-2xl p-10 shadow-md"
            >
              <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#1D4E89] to-[#276FBF] flex items-center justify-center text-white mb-6">
                <Target size={32} />
              </div>
              <h2 className="text-[#1D4E89] mb-4">Our Mission</h2>
              <p className="text-[#AAB6C9]">
                To empower organizations with innovative technology solutions and exceptional creative content that drive digital transformation, enhance operational efficiency, and elevate brand presence in the global marketplace.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-white rounded-2xl p-10 shadow-md"
            >
              <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#0A84FF] to-[#76A9E0] flex items-center justify-center text-white mb-6">
                <Eye size={32} />
              </div>
              <h2 className="text-[#1D4E89] mb-4">Our Vision</h2>
              <p className="text-[#AAB6C9]">
                To be recognized as the leading integrated technology and creative solutions provider in the Middle East, known for delivering world-class enterprise systems and premium creative productions that set new industry standards.
              </p>
            </motion.div>
          </div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <SectionHeader
            subtitle="Our Values"
            title="Principles That Guide Our Work"
            description="These core values shape our culture, guide our decisions, and define how we deliver exceptional results for our clients."
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-16">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-[#F4F7FB] rounded-xl p-8"
              >
                <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-[#1D4E89] to-[#276FBF] flex items-center justify-center text-white mb-4">
                  {value.icon}
                </div>
                <h3 className="text-[#1D4E89] mb-3">{value.title}</h3>
                <p className="text-[#AAB6C9] text-sm">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 bg-[#F4F7FB]">
        <Container>
          <SectionHeader
            subtitle="Our Expertise"
            title="Comprehensive Technical & Creative Capabilities"
            description="Our multidisciplinary team brings together expertise across diverse domains to deliver integrated solutions."
          />

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-16"
          >
            {expertise.map((item, index) => (
              <div
                key={index}
                className="bg-white rounded-lg p-4 text-center text-[#1D4E89] text-sm border border-[#E9EEF5] hover:border-[#276FBF] hover:shadow-md transition-all"
              >
                {item}
              </div>
            ))}
          </motion.div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <div className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] rounded-3xl p-12 text-center text-white">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="mb-4">Partner With Us</h2>
              <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
                Join leading organizations that trust Haditra for their technology and creative needs. Let's build something exceptional together.
              </p>
              <CTAButton to="/contact">Start a Conversation</CTAButton>
            </motion.div>
          </div>
        </Container>
      </section>
    </div>
  );
}
