import { motion } from 'motion/react';
import { Container } from '../components/ui/Container';
import { SectionHeader } from '../components/ui/SectionHeader';
import { ServiceCard } from '../components/ui/ServiceCard';
import { CTAButton } from '../components/ui/CTAButton';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { 
  Brain, 
  TrendingUp, 
  ScanFace, 
  Eye,
  Radio,
  Cpu,
  MessageSquare,
  Mic,
  BarChart3,
  Shield,
  Zap,
  Target
} from 'lucide-react';

export function AITechnologies() {
  const services = [
    {
      icon: <Brain size={24} />,
      title: 'Machine Learning Analytics',
      description: 'Advanced ML models that analyze complex datasets to uncover patterns, predict trends, and provide actionable insights for data-driven decision making.',
      features: ['Predictive modeling', 'Pattern recognition', 'Anomaly detection', 'Custom algorithms']
    },
    {
      icon: <TrendingUp size={24} />,
      title: 'Predictive Systems',
      description: 'Forecasting solutions that leverage historical data and real-time inputs to predict future outcomes, optimize operations, and reduce risks.',
      features: ['Demand forecasting', 'Risk assessment', 'Trend analysis', 'Resource optimization']
    },
    {
      icon: <ScanFace size={24} />,
      title: 'Face Recognition',
      description: 'State-of-the-art facial recognition technology for secure access control, attendance systems, and customer identification with privacy compliance.',
      features: ['Real-time detection', 'Liveness verification', 'Multi-face tracking', 'Privacy-first design']
    },
    {
      icon: <Eye size={24} />,
      title: 'Object Detection',
      description: 'Computer vision systems that identify, classify, and track objects in images and videos for surveillance, quality control, and automation.',
      features: ['Real-time detection', 'Multi-class classification', 'Tracking algorithms', 'Edge deployment']
    },
    {
      icon: <Radio size={24} />,
      title: 'IoT Integration',
      description: 'Intelligent IoT platforms that connect devices, collect data, and use AI to optimize performance and enable predictive maintenance.',
      features: ['Device management', 'Edge computing', 'Real-time analytics', 'Automated responses']
    },
    {
      icon: <Cpu size={24} />,
      title: 'Smart Systems',
      description: 'Autonomous systems that learn from data, adapt to changing conditions, and make intelligent decisions without human intervention.',
      features: ['Adaptive learning', 'Autonomous operation', 'Self-optimization', 'Intelligent automation']
    },
    {
      icon: <MessageSquare size={24} />,
      title: 'Chatbots & NLP',
      description: 'Conversational AI powered by natural language processing to understand context, sentiment, and intent for superior customer interactions.',
      features: ['Multi-language support', 'Sentiment analysis', 'Context awareness', 'Integration ready']
    },
    {
      icon: <Mic size={24} />,
      title: 'Voice Assistants',
      description: 'Voice-enabled AI assistants that understand natural speech, process commands, and provide hands-free interaction with your systems.',
      features: ['Speech recognition', 'Natural responses', 'Custom commands', 'Multi-platform']
    }
  ];

  const benefits = [
    {
      icon: <BarChart3 size={28} />,
      title: 'Data-Driven Insights',
      description: 'Transform raw data into actionable intelligence that drives strategic decisions and competitive advantages.'
    },
    {
      icon: <Zap size={28} />,
      title: 'Operational Efficiency',
      description: 'Automate complex processes and optimize resource allocation to reduce costs and improve productivity.'
    },
    {
      icon: <Target size={28} />,
      title: 'Enhanced Accuracy',
      description: 'Minimize human error and achieve consistent results with AI-powered precision and reliability.'
    },
    {
      icon: <Shield size={28} />,
      title: 'Proactive Security',
      description: 'Detect threats, anomalies, and vulnerabilities in real-time with intelligent monitoring systems.'
    }
  ];

  return (
    <div>
      <section className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] py-20 text-white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="mb-6">AI & Advanced Technologies</h1>
            <p className="text-lg text-white/90">
              Cutting-edge artificial intelligence and machine learning solutions that transform data into intelligence, automate complex processes, and create competitive advantages.
            </p>
          </motion.div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="rounded-2xl overflow-hidden shadow-xl"
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1674027444485-cec3da58eef4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpZmljaWFsJTIwaW50ZWxsaWdlbmNlJTIwbmV0d29ya3xlbnwxfHx8fDE3NjMxMjU5Mjh8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="AI technology visualization"
                className="w-full h-auto"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-[#0A84FF] text-sm tracking-wide uppercase mb-4">
                The Future is Intelligent
              </div>
              <h2 className="text-[#1D4E89] mb-6">
                Harness the Power of Artificial Intelligence
              </h2>
              <p className="text-[#AAB6C9] mb-4">
                Our AI and machine learning solutions are designed to solve real-world business challenges. We develop custom models trained on your data, ensuring solutions that are tailored to your specific needs and deliver measurable results.
              </p>
              <p className="text-[#AAB6C9] mb-6">
                From predictive analytics to computer vision, natural language processing to intelligent automation, we bring the latest AI innovations to your organization with practical, scalable implementations.
              </p>
              <CTAButton to="/contact">Explore AI Solutions</CTAButton>
            </motion.div>
          </div>
        </Container>
      </section>

      <section className="py-20 bg-[#F4F7FB]">
        <Container>
          <SectionHeader
            subtitle="AI Capabilities"
            title="Comprehensive AI & ML Solutions"
            description="Our AI technology stack covers the full spectrum of artificial intelligence applications, from data analytics to autonomous systems."
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16">
            {services.map((service, index) => (
              <ServiceCard
                key={index}
                icon={service.icon}
                title={service.title}
                description={service.description}
                features={service.features}
                delay={index * 0.05}
              />
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <SectionHeader
            subtitle="Why AI Matters"
            title="Transform Your Business with Intelligence"
            description="Artificial intelligence is not just technology—it's a strategic advantage that enables smarter decisions, faster operations, and better outcomes."
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mt-16">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#1D4E89] to-[#276FBF] flex items-center justify-center text-white">
                  {benefit.icon}
                </div>
                <h3 className="text-[#1D4E89] mb-3">{benefit.title}</h3>
                <p className="text-[#AAB6C9] text-sm">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 bg-[#F4F7FB]">
        <Container>
          <div className="bg-white rounded-3xl p-12 shadow-lg">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <div className="text-[#0A84FF] text-sm tracking-wide uppercase mb-4">
                  Our Process
                </div>
                <h2 className="text-[#1D4E89] mb-6">
                  From Concept to Deployment
                </h2>
                <div className="space-y-4">
                  {[
                    { step: '01', title: 'Discovery & Analysis', desc: 'Understanding your business challenges and data landscape' },
                    { step: '02', title: 'Model Development', desc: 'Building and training custom AI models for your needs' },
                    { step: '03', title: 'Integration & Testing', desc: 'Seamless integration with your existing systems' },
                    { step: '04', title: 'Deployment & Support', desc: 'Ongoing monitoring, optimization, and enhancement' }
                  ].map((item, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="text-2xl text-[#0A84FF] font-light">{item.step}</div>
                      <div>
                        <div className="text-[#1D4E89] mb-1">{item.title}</div>
                        <div className="text-[#AAB6C9] text-sm">{item.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] rounded-2xl p-10 text-white"
              >
                <h3 className="mb-4">Ready to Implement AI?</h3>
                <p className="text-white/90 mb-8">
                  Let's discuss how artificial intelligence can solve your specific business challenges and create measurable value.
                </p>
                <CTAButton to="/contact">Schedule AI Consultation</CTAButton>
              </motion.div>
            </div>
          </div>
        </Container>
      </section>
    </div>
  );
}
