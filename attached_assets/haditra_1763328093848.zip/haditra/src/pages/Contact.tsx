import { useState } from 'react';
import { motion } from 'motion/react';
import { Container } from '../components/ui/Container';
import { SectionHeader } from '../components/ui/SectionHeader';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { MapPin, Phone, Mail, Clock, Send, Upload, CheckCircle2 } from 'lucide-react';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    serviceType: '',
    message: '',
    file: null as File | null
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      setFormData({
        name: '',
        company: '',
        email: '',
        serviceType: '',
        message: '',
        file: null
      });
      setIsSubmitted(false);
    }, 3000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData({ ...formData, file: e.target.files[0] });
    }
  };

  const contactInfo = [
    {
      icon: <MapPin size={24} />,
      title: 'Office Location',
      content: 'Dubai, United Arab Emirates',
      subContent: 'Business Bay, Sheikh Zayed Road'
    },
    {
      icon: <Phone size={24} />,
      title: 'Phone Number',
      content: '+971 XX XXX XXXX',
      subContent: 'Available 24/7'
    },
    {
      icon: <Mail size={24} />,
      title: 'Email Address',
      content: 'info@haditra.com',
      subContent: 'Response within 24 hours'
    },
    {
      icon: <Clock size={24} />,
      title: 'Business Hours',
      content: 'Sunday - Thursday',
      subContent: '9:00 AM - 6:00 PM GST'
    }
  ];

  return (
    <div>
      <section className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] py-20 text-white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="mb-6">Get In Touch</h1>
            <p className="text-lg text-white/90">
              Ready to start your project? Contact our team and let's discuss how we can help transform your vision into reality.
            </p>
          </motion.div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <div className="grid lg:grid-cols-3 gap-8 mb-16">
            {contactInfo.map((info, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-[#F4F7FB] rounded-2xl p-8 text-center"
              >
                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#1D4E89] to-[#276FBF] flex items-center justify-center text-white">
                  {info.icon}
                </div>
                <h3 className="text-[#1D4E89] mb-2">{info.title}</h3>
                <p className="text-[#276FBF] mb-1">{info.content}</p>
                <p className="text-[#AAB6C9] text-sm">{info.subContent}</p>
              </motion.div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-[#0A84FF] text-sm tracking-wide uppercase mb-4">
                Send Us a Message
              </div>
              <h2 className="text-[#1D4E89] mb-6">
                Let's Discuss Your Project
              </h2>
              <p className="text-[#AAB6C9] mb-8">
                Fill out the form below and our team will get back to you within 24 hours. For urgent inquiries, please call us directly.
              </p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm text-[#1D4E89] mb-2">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg border border-[#E9EEF5] focus:outline-none focus:border-[#276FBF] transition-colors"
                      placeholder="John Smith"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-[#1D4E89] mb-2">Company Name</label>
                    <input
                      type="text"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg border border-[#E9EEF5] focus:outline-none focus:border-[#276FBF] transition-colors"
                      placeholder="Your Company"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-[#1D4E89] mb-2">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 rounded-lg border border-[#E9EEF5] focus:outline-none focus:border-[#276FBF] transition-colors"
                    placeholder="john@company.com"
                  />
                </div>

                <div>
                  <label className="block text-sm text-[#1D4E89] mb-2">Service Type *</label>
                  <select
                    required
                    value={formData.serviceType}
                    onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                    className="w-full px-4 py-3 rounded-lg border border-[#E9EEF5] focus:outline-none focus:border-[#276FBF] transition-colors bg-white"
                  >
                    <option value="">Select a service</option>
                    <option value="software">Software Engineering</option>
                    <option value="ai">AI & Advanced Technologies</option>
                    <option value="creative">Creative Studio</option>
                    <option value="video">Video Production</option>
                    <option value="branding">Branding & Design</option>
                    <option value="consultation">General Consultation</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-[#1D4E89] mb-2">Message *</label>
                  <textarea
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={6}
                    className="w-full px-4 py-3 rounded-lg border border-[#E9EEF5] focus:outline-none focus:border-[#276FBF] transition-colors resize-none"
                    placeholder="Tell us about your project requirements..."
                  />
                </div>

                <div>
                  <label className="block text-sm text-[#1D4E89] mb-2">Attach Files</label>
                  <div className="relative">
                    <input
                      type="file"
                      onChange={handleFileChange}
                      className="hidden"
                      id="file-upload"
                      accept=".pdf,.doc,.docx,.ppt,.pptx"
                    />
                    <label
                      htmlFor="file-upload"
                      className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-lg border-2 border-dashed border-[#E9EEF5] hover:border-[#276FBF] transition-colors cursor-pointer"
                    >
                      <Upload size={20} className="text-[#AAB6C9]" />
                      <span className="text-[#AAB6C9]">
                        {formData.file ? formData.file.name : 'Click to upload (PDF, DOC, PPT)'}
                      </span>
                    </label>
                  </div>
                </div>

                {isSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex items-center justify-center gap-2 bg-green-50 text-green-700 px-6 py-4 rounded-lg"
                  >
                    <CheckCircle2 size={20} />
                    <span>Thank you! Your message has been sent successfully.</span>
                  </motion.div>
                ) : (
                  <button
                    type="submit"
                    className="w-full bg-[#0A84FF] text-white px-6 py-4 rounded-lg hover:bg-[#276FBF] transition-colors flex items-center justify-center gap-2"
                  >
                    Send Message
                    <Send size={20} />
                  </button>
                )}
              </form>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="space-y-8"
            >
              <div className="bg-[#F4F7FB] rounded-2xl p-8">
                <h3 className="text-[#1D4E89] mb-4">Why Choose Haditra?</h3>
                <ul className="space-y-4">
                  {[
                    'Enterprise-grade solutions with proven track record',
                    'Multidisciplinary team of experts',
                    'End-to-end project delivery',
                    'Transparent communication and pricing',
                    'Ongoing support and maintenance',
                    'Innovative technology stack'
                  ].map((item, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <CheckCircle2 size={20} className="text-[#0A84FF] mt-0.5 flex-shrink-0" />
                      <span className="text-[#AAB6C9]">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] rounded-2xl p-8 text-white">
                <h3 className="mb-4">Location Map</h3>
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-center border border-white/20">
                  <MapPin size={40} className="mx-auto mb-4 text-white/80" />
                  <p className="text-white/90 mb-2">Haditra Technologies</p>
                  <p className="text-white/70 text-sm mb-4">
                    Business Bay, Sheikh Zayed Road<br />
                    Dubai, United Arab Emirates
                  </p>
                  <a
                    href="https://maps.google.com/?q=Dubai+Business+Bay"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm text-white/90 hover:text-white transition-colors"
                  >
                    Open in Google Maps →
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </Container>
      </section>
    </div>
  );
}
