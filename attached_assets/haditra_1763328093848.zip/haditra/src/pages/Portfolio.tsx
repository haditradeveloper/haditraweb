import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Container } from '../components/ui/Container';
import { SectionHeader } from '../components/ui/SectionHeader';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { Filter } from 'lucide-react';

export function Portfolio() {
  const [activeFilter, setActiveFilter] = useState('all');

  const categories = [
    { id: 'all', label: 'All Projects' },
    { id: 'software', label: 'Software' },
    { id: 'ai', label: 'AI & Data' },
    { id: 'creative', label: 'Creative Studio' },
    { id: 'video', label: 'Video Production' },
    { id: 'branding', label: 'Branding' }
  ];

  const projects = [
    {
      id: 1,
      category: 'software',
      title: 'Enterprise Payment Gateway',
      description: 'Secure payment processing system handling millions in transactions',
      image: 'https://images.unsplash.com/photo-1605108222700-0d605d9ebafe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzYzMTQ5NTgwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Global Finance Corp',
      tags: ['Fintech', 'Payment Systems']
    },
    {
      id: 2,
      category: 'software',
      title: 'E-Commerce Platform',
      description: 'Multi-vendor marketplace with advanced analytics',
      image: 'https://images.unsplash.com/photo-1658297063569-162817482fb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY29tbWVyY2UlMjB3ZWJzaXRlfGVufDF8fHx8MTc2MzA2ODIxMHww&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Retail Innovations Ltd',
      tags: ['E-Commerce', 'Web Platform']
    },
    {
      id: 3,
      category: 'ai',
      title: 'Predictive Analytics Dashboard',
      description: 'AI-powered business intelligence and forecasting',
      image: 'https://images.unsplash.com/photo-1759661966728-4a02e3c6ed91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwdmlzdWFsaXphdGlvbiUyMGRhc2hib2FyZHxlbnwxfHx8fDE3NjMwOTEzMzF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Data Solutions Inc',
      tags: ['Machine Learning', 'Analytics']
    },
    {
      id: 4,
      category: 'ai',
      title: 'Face Recognition System',
      description: 'Advanced biometric access control for corporate facilities',
      image: 'https://images.unsplash.com/photo-1674027444485-cec3da58eef4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpZmljaWFsJTIwaW50ZWxsaWdlbmNlJTIwbmV0d29ya3xlbnwxfHx8fDE3NjMxMjU5Mjh8MA&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Security Systems ME',
      tags: ['Computer Vision', 'Security']
    },
    {
      id: 5,
      category: 'creative',
      title: 'Architectural Visualization',
      description: '3D rendering and animation for luxury development',
      image: 'https://images.unsplash.com/photo-1668015642134-272d73b8f306?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcmNoaXRlY3R1cmFsJTIwcmVuZGVyaW5nfGVufDF8fHx8MTc2MzE1NjYwOHww&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Dubai Real Estate Group',
      tags: ['3D Animation', 'Architecture']
    },
    {
      id: 6,
      category: 'video',
      title: 'Corporate Video Production',
      description: 'Brand documentary series showcasing company culture',
      image: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWRlbyUyMGVkaXRpbmclMjB0aW1lbGluZXxlbnwxfHx8fDE3NjMwNDYxODh8MA&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Emirates Business Group',
      tags: ['Video Production', 'Corporate']
    },
    {
      id: 7,
      category: 'branding',
      title: 'Brand Identity System',
      description: 'Complete brand redesign with logo, guidelines, and collateral',
      image: 'https://images.unsplash.com/photo-1640975972263-1f73398e943b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZCUyMGRlc2lnbiUyMGxvZ298ZW58MXx8fHwxNzYzMTU2NjA4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Luxury Brands ME',
      tags: ['Branding', 'Graphic Design']
    },
    {
      id: 8,
      category: 'creative',
      title: 'Product Photography Campaign',
      description: 'Studio shooting for fashion collection catalog',
      image: 'https://images.unsplash.com/photo-1632937145991-91620be68319?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGRlc2lnbiUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NjMwODI5NzF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Fashion House Dubai',
      tags: ['Photography', 'Product']
    },
    {
      id: 9,
      category: 'software',
      title: 'HR Management System',
      description: 'Comprehensive HRMS with payroll and performance tracking',
      image: 'https://images.unsplash.com/photo-1689467892123-107febc3311f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB0ZWNobm9sb2d5JTIwb2ZmaWNlfGVufDF8fHx8MTc2MzEwMTI5OHww&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Corporate Solutions LLC',
      tags: ['Enterprise Software', 'HR']
    },
    {
      id: 10,
      category: 'video',
      title: 'Aerial Drone Cinematography',
      description: 'Stunning aerial footage for tourism campaign',
      image: 'https://images.unsplash.com/photo-1673767297196-ce9739933932?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWRlbyUyMHByb2R1Y3Rpb24lMjBzdHVkaW98ZW58MXx8fHwxNzYzMTE0NzA1fDA&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Tourism Board UAE',
      tags: ['Drone', 'Cinematography']
    },
    {
      id: 11,
      category: 'ai',
      title: 'IoT Monitoring Platform',
      description: 'Real-time monitoring and analytics for smart buildings',
      image: 'https://images.unsplash.com/photo-1531498860502-7c67cf02f657?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2Z0d2FyZSUyMGRldmVsb3BtZW50JTIwY29kZXxlbnwxfHx8fDE3NjMxMjU3NTN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Smart City Initiative',
      tags: ['IoT', 'Cloud Platform']
    },
    {
      id: 12,
      category: 'creative',
      title: 'Motion Graphics Package',
      description: 'Animated explainer videos for tech startup',
      image: 'https://images.unsplash.com/photo-1709715357520-5e1047a2b691?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHRlYW0lMjBtZWV0aW5nfGVufDF8fHx8MTc2MzExNzg4NHww&ixlib=rb-4.1.0&q=80&w=1080',
      client: 'Tech Innovations Ltd',
      tags: ['Motion Graphics', 'Animation']
    }
  ];

  const filteredProjects = activeFilter === 'all' 
    ? projects 
    : projects.filter(p => p.category === activeFilter);

  return (
    <div>
      <section className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] py-20 text-white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="mb-6">Our Portfolio</h1>
            <p className="text-lg text-white/90">
              Explore our diverse range of successful projects spanning software development, AI solutions, and creative productions.
            </p>
          </motion.div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <div className="flex flex-wrap items-center justify-center gap-3 mb-16">
            <div className="flex items-center gap-2 text-[#AAB6C9] mr-4">
              <Filter size={20} />
              <span className="text-sm">Filter:</span>
            </div>
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveFilter(category.id)}
                className={`px-6 py-2 rounded-full text-sm transition-all ${
                  activeFilter === category.id
                    ? 'bg-[#1D4E89] text-white shadow-md'
                    : 'bg-[#F4F7FB] text-[#AAB6C9] hover:bg-[#E9EEF5] hover:text-[#276FBF]'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeFilter}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {filteredProjects.map((project, index) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-[#E9EEF5]"
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-[#F4F7FB]">
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-[#1D4E89]/90 text-white text-xs rounded-full backdrop-blur-sm">
                        {categories.find(c => c.id === project.category)?.label}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-[#1D4E89] mb-2">{project.title}</h3>
                    <p className="text-[#AAB6C9] text-sm mb-4">{project.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#AAB6C9]">{project.client}</span>
                      <div className="flex gap-2">
                        {project.tags.map((tag, tagIndex) => (
                          <span
                            key={tagIndex}
                            className="text-xs text-[#0A84FF] bg-[#F4F7FB] px-2 py-1 rounded"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>

          {filteredProjects.length === 0 && (
            <div className="text-center py-20">
              <p className="text-[#AAB6C9]">No projects found in this category.</p>
            </div>
          )}
        </Container>
      </section>

      <section className="py-20 bg-[#F4F7FB]">
        <Container>
          <SectionHeader
            subtitle="Client Success"
            title="Delivering Results That Matter"
            description="Every project is a partnership focused on achieving measurable outcomes and exceeding expectations."
          />

          <div className="grid md:grid-cols-4 gap-8 mt-16">
            {[
              { value: '150+', label: 'Software Projects' },
              { value: '80+', label: 'AI Implementations' },
              { value: '200+', label: 'Creative Productions' },
              { value: '98%', label: 'Client Satisfaction' }
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center bg-white rounded-xl p-8 border border-[#E9EEF5]"
              >
                <div className="text-[#1D4E89] text-4xl mb-2">{stat.value}</div>
                <div className="text-[#AAB6C9] text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </Container>
      </section>
    </div>
  );
}
