import { motion } from 'motion/react';
import { Container } from '../components/ui/Container';
import { SectionHeader } from '../components/ui/SectionHeader';
import { CTAButton } from '../components/ui/CTAButton';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { 
  CreditCard, 
  Wallet, 
  Building2, 
  Users, 
  Bot, 
  Brain,
  Radio,
  ScanFace,
  Share2,
  ShoppingCart,
  Zap,
  Database
} from 'lucide-react';

export function SoftwareSolutions() {
  const solutions = [
    {
      icon: <CreditCard size={32} />,
      title: 'Payment Systems',
      problem: 'Organizations need secure, compliant, and scalable payment processing infrastructure for digital transactions.',
      description: 'Comprehensive payment gateway integration and processing systems with multi-currency support, fraud detection, and real-time transaction monitoring.',
      technologies: ['PCI DSS Compliance', 'Stripe API', 'PayPal Integration', 'Blockchain', 'Secure Tokenization'],
      useCases: ['E-commerce platforms', 'Subscription services', 'Marketplace solutions', 'Financial applications']
    },
    {
      icon: <Wallet size={32} />,
      title: 'Digital Wallet Solutions',
      problem: 'Modern consumers demand seamless, secure digital payment experiences across all touchpoints.',
      description: 'Advanced digital wallet platforms with biometric authentication, NFC payments, loyalty programs, and peer-to-peer transfer capabilities.',
      technologies: ['Mobile SDK', 'Biometric Auth', 'QR Code', 'NFC Technology', 'Cloud Infrastructure'],
      useCases: ['Mobile banking', 'Retail payments', 'Transportation', 'Loyalty programs']
    },
    {
      icon: <Building2 size={32} />,
      title: 'Enterprise Resource Planning (ERP)',
      problem: 'Businesses struggle with fragmented systems that create data silos and operational inefficiencies.',
      description: 'Integrated ERP solutions that unify financial management, supply chain, inventory, manufacturing, and business intelligence into a single platform.',
      technologies: ['Microservices', 'REST APIs', 'PostgreSQL', 'Redis', 'React Dashboard'],
      useCases: ['Manufacturing', 'Distribution', 'Retail chains', 'Service industries']
    },
    {
      icon: <Users size={32} />,
      title: 'Human Resources Management Systems',
      problem: 'HR departments need comprehensive tools to manage workforce lifecycle from recruitment to retirement.',
      description: 'Complete HRMS platforms covering recruitment, onboarding, payroll, performance management, time tracking, and employee self-service portals.',
      technologies: ['Workflow Automation', 'Document Management', 'Payroll Engine', 'Analytics Dashboard', 'Mobile Apps'],
      useCases: ['Corporate HR', 'Recruitment agencies', 'Payroll services', 'Training management']
    },
    {
      icon: <Bot size={32} />,
      title: 'Automation & RPA',
      problem: 'Repetitive manual tasks consume valuable time and resources while introducing human errors.',
      description: 'Intelligent automation solutions using robotic process automation to streamline workflows, reduce costs, and improve accuracy in business operations.',
      technologies: ['Python', 'UiPath', 'Process Mining', 'OCR Technology', 'API Integration'],
      useCases: ['Data entry automation', 'Invoice processing', 'Report generation', 'Customer onboarding']
    },
    {
      icon: <Brain size={32} />,
      title: 'AI & Machine Learning Solutions',
      problem: 'Organizations have vast amounts of data but lack the tools to extract actionable insights.',
      description: 'Custom AI/ML models for predictive analytics, natural language processing, computer vision, and intelligent decision-making systems.',
      technologies: ['TensorFlow', 'PyTorch', 'scikit-learn', 'Neural Networks', 'Deep Learning'],
      useCases: ['Predictive maintenance', 'Customer segmentation', 'Fraud detection', 'Demand forecasting']
    },
    {
      icon: <Radio size={32} />,
      title: 'IoT Systems',
      problem: 'Connected devices need robust platforms for data collection, processing, and real-time monitoring.',
      description: 'End-to-end IoT solutions including sensor integration, edge computing, real-time analytics, and cloud-based monitoring dashboards.',
      technologies: ['MQTT Protocol', 'Edge Computing', 'Time-Series DB', 'AWS IoT', 'Device Management'],
      useCases: ['Smart buildings', 'Industrial monitoring', 'Fleet management', 'Environmental sensing']
    },
    {
      icon: <ScanFace size={32} />,
      title: 'Face Recognition Systems',
      problem: 'Security and identity verification require accurate, fast, and privacy-compliant biometric solutions.',
      description: 'Advanced facial recognition systems for access control, attendance tracking, customer identification, and security applications.',
      technologies: ['OpenCV', 'Deep Learning', 'Liveness Detection', 'GDPR Compliance', 'Edge Processing'],
      useCases: ['Access control', 'Time attendance', 'Customer analytics', 'Security surveillance']
    },
    {
      icon: <Share2 size={32} />,
      title: 'Social Media Platforms',
      problem: 'Communities and organizations need custom platforms for engagement, content sharing, and networking.',
      description: 'Scalable social networking platforms with real-time messaging, content feeds, user profiles, moderation tools, and engagement analytics.',
      technologies: ['WebSocket', 'CDN', 'Redis Cache', 'Elasticsearch', 'Microservices'],
      useCases: ['Corporate communities', 'Professional networks', 'Interest-based platforms', 'Educational networks']
    },
    {
      icon: <ShoppingCart size={32} />,
      title: 'E-Commerce Software',
      problem: 'Online retailers need powerful platforms that handle complex catalogs, payments, and customer experiences.',
      description: 'Complete e-commerce solutions with product management, multi-vendor support, advanced search, payment integration, and analytics.',
      technologies: ['Headless CMS', 'Payment Gateway', 'Inventory Sync', 'SEO Optimization', 'Progressive Web App'],
      useCases: ['Online retail', 'Marketplace platforms', 'B2B commerce', 'Subscription boxes']
    }
  ];

  return (
    <div>
      <section className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] py-20 text-white">
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="mb-6">Software Engineering Solutions</h1>
            <p className="text-lg text-white/90">
              Enterprise-grade custom software systems designed to transform business operations, enhance efficiency, and drive digital innovation across industries.
            </p>
          </motion.div>
        </Container>
      </section>

      <section className="py-20 bg-white">
        <Container>
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-[#0A84FF] text-sm tracking-wide uppercase mb-4">
                Our Approach
              </div>
              <h2 className="text-[#1D4E89] mb-6">
                Building Software That Drives Business Success
              </h2>
              <p className="text-[#AAB6C9] mb-4">
                We combine deep technical expertise with business understanding to create software solutions that solve real problems. Our development process emphasizes scalability, security, and user experience.
              </p>
              <p className="text-[#AAB6C9] mb-6">
                From initial consultation to deployment and ongoing support, we partner with you to ensure your software investment delivers measurable returns and competitive advantages.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="rounded-2xl overflow-hidden shadow-xl"
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1531498860502-7c67cf02f657?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2Z0d2FyZSUyMGRldmVsb3BtZW50JTIwY29kZXxlbnwxfHx8fDE3NjMxMjU3NTN8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Software development"
                className="w-full h-auto"
              />
            </motion.div>
          </div>

          <div className="space-y-16">
            {solutions.map((solution, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-[#F4F7FB] rounded-3xl overflow-hidden"
              >
                <div className="grid lg:grid-cols-2 gap-0">
                  <div className="p-10 lg:p-12">
                    <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#1D4E89] to-[#276FBF] flex items-center justify-center text-white mb-6">
                      {solution.icon}
                    </div>
                    <h2 className="text-[#1D4E89] mb-4">{solution.title}</h2>
                    
                    <div className="mb-6">
                      <div className="text-sm text-[#0A84FF] uppercase tracking-wide mb-2">Problem</div>
                      <p className="text-[#AAB6C9]">{solution.problem}</p>
                    </div>

                    <div className="mb-6">
                      <div className="text-sm text-[#0A84FF] uppercase tracking-wide mb-2">Solution</div>
                      <p className="text-[#AAB6C9]">{solution.description}</p>
                    </div>

                    <CTAButton to="/contact">Request a Demo</CTAButton>
                  </div>

                  <div className="bg-white p-10 lg:p-12 flex flex-col justify-center">
                    <div className="mb-8">
                      <div className="text-sm text-[#1D4E89] uppercase tracking-wide mb-4">Technologies</div>
                      <div className="flex flex-wrap gap-2">
                        {solution.technologies.map((tech, techIndex) => (
                          <span
                            key={techIndex}
                            className="px-4 py-2 bg-[#F4F7FB] text-[#276FBF] text-sm rounded-lg border border-[#E9EEF5]"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm text-[#1D4E89] uppercase tracking-wide mb-4">Use Cases</div>
                      <ul className="space-y-2">
                        {solution.useCases.map((useCase, ucIndex) => (
                          <li key={ucIndex} className="flex items-start gap-2 text-[#AAB6C9]">
                            <Zap size={16} className="text-[#0A84FF] mt-1 flex-shrink-0" />
                            <span>{useCase}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 bg-[#F4F7FB]">
        <Container>
          <div className="bg-gradient-to-br from-[#1D4E89] to-[#276FBF] rounded-3xl p-12 text-center text-white">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="mb-4">Ready to Build Your Solution?</h2>
              <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
                Let's discuss your software requirements and create a custom solution that meets your business objectives.
              </p>
              <CTAButton to="/contact">Schedule Consultation</CTAButton>
            </motion.div>
          </div>
        </Container>
      </section>
    </div>
  );
}
